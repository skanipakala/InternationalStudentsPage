import json
from urllib.request import urlopen
from slack_sdk import WebClient
from slack_sdk.errors import SlackApiError


SLACK_SIGNING_SECRET = "be7f0362f0ef42faf3ce1c05357a7617"
slack_token = "xoxb-3571563540-2852161980819-6ZSV4tBlJfqsYF4cGk171aCg"
VERIFICATION_TOKEN = "eeScInmUh4q2kluS2gyjMqaB"

# # Get Major
# def lambda_handler(event, context):
#     print("[!] access to major triggered")
#     umdRequest = urlopen("https://api.umd.io/v1/majors/list")
#     data = json.load(umdRequest)

#     # Target_request is the text data after /major
#     target_request  = json.loads(event['body'])['text'].strip()

#     # Initialized found to false and targetField o empty
#     found = False
#     target_field = ""
#     for field in data:     
#         if target_request.upper() == field['name'].strip().upper():        
#             found = True
#             target_field = field            

#     if found:
#         custom_text = "✔️ " +  target_request + " is a major. It is in the " + target_field['college']
#     else:
#         custom_text = "⚠️ Major does not exist. Check spelling or the list of majors here: https://www.admissions.umd.edu/explore/majors"

#     # Constructing the repsonse object
#     response = json.dumps({'message': custom_text})

#     return {
#         'statusCode': 200,
#         'body': response
#     }

# Get Major
def lambda_handler(event, context):
    print("[!] access to major triggered")

    # Verify the request by checking the signing secret and token
    slack_events_api_secret = SLACK_SIGNING_SECRET
    request_body = json.loads(event['body'])
    verification_header = event['headers']['X-Slack-Signature']

    # Check the signing secret
    client = WebClient(token=slack_token)
    try:
        client.validate_signature(slack_events_api_secret, request_body, verification_header)
    except SlackApiError as e:
        return {
            'statusCode': 401,
            'body': 'Invalid request'
        }

    # Check the token
    token = request_body['token']
    if token != VERIFICATION_TOKEN:
        return {
            'statusCode': 401,
            'body': 'Invalid request'
        }

    # Get the major data
    umdRequest = urlopen("https://api.umd.io/v1/majors/list")
    data = json.load(umdRequest)

    # Target_request is the text data after /major
    target_request  = request_body['text'].strip()

    # Initialized found to false and targetField o empty
    found = False
    target_field = ""
    for field in data:     
        if target_request.upper() == field['name'].strip().upper():        
            found = True
            target_field = field            

    if found:
        custom_text = "✔️ " +  target_request + " is a major. It is in the " + target_field['college']
    else:
        custom_text = "⚠️ Major does not exist. Check spelling or the list of majors here: https://www.admissions.umd.edu/explore/majors"

    # Send the response to Slack
    try:
        response = client.chat_postMessage(
            channel="#general",
            text=custom_text
        )
    except SlackApiError as e:
        return {
            'statusCode': 500,
            'body': 'Error posting message to Slack: {}'.format(e)
        }

    return {
        'statusCode': 200,
        'body': 'OK'
    }
