from flask import Flask, request, Response, make_response
from slackeventsapi import SlackEventAdapter

import requests
from bs4 import BeautifulSoup
import pandas as pd

import difflib
import numpy as np

import slack
from slack_sdk import WebClient
import simplejson as json
import urllib
import datetime
import threading
from threading import Thread




# This `app` represents your existing Flask app
app = Flask(__name__)


SLACK_SIGNING_SECRET = "be7f0362f0ef42faf3ce1c05357a7617"
slack_token = "xoxb-3571563540-2852161980819-6ZSV4tBlJfqsYF4cGk171aCg"
VERIFICATION_TOKEN = "eeScInmUh4q2kluS2gyjMqaB"

#years
freshman = "freshman"
sophomore  = "sophomore"
junior = "junior"
senior = "senior"
rfreshman = "redshirt freshman"
rsophomore  = "redshirt sophomore"
rjunior = "redshirt junior"
rsenior = "redshirt senior"
graduate = "gradaute student"
years = {'Fr.':freshman, 'So.': sophomore, 'Jr.':junior,
    'Sr.':senior,'R-Fr.':rfreshman,'R-So.':rsophomore,'R-Jr.':rjunior, 'R-Sr.':rsenior,'Gr.':graduate}

#react alphabet
reacts = {'A':':a:','B':':b:','C':':copyright:','D':':leftwards_arrow_with_hook:','E':':e-mail:','F':':flags:','G':':minidisc:',
        'H':':hotel:','I':':information_source:','J':':j:', 'K':':tanabata_tree:','L':':e-scooter:','M':':mcdonalds:','N':':capricorn:','O':':o:','P':':parking:',
        'Q':':qanon:','R':':r:','S':':s:','T':':t:','U':':u:','V':':verified:','W':':wordpress:','X':':x:','Y':':y:','Z':':snake:','!':':bang:','?':':interrobang:',' ':'     ',
        '1':':one:','2':':two:','3':':three:','4':':four:','5':':five:','6':':six:','7':':seven:','8':':eight:','9':':nine:'}
sports = ["⚾ BASEBALL", "🏑 FIELD HOCKEY", "🏈 FOOTBALL", "🤸‍♀️ GYMNASTICS", "🏀 MEN'S BASKETBALL", "🥍 MEN'S LACROSSE", "⚽ MEN'S SOCCER", "🥎 SOFTBALL", "🏐 VOLLEYBALL", "🏀 WOMEN'S BASKETBALL", "🥍 WOMEN'S LACROSSE", "⚽ WOMEN'S SOCCER", "🎾 WOMEN'S TENNIS", "🤼‍♂️ WRESTLING" ]

#instantiating slack client
#client = slack.WebClient(slack_token)
client = WebClient(token=slack_token)

# An example of one of your Flask app's routes
@app.route("/")
def event_hook():
    print("main page, HOME")
    return {"status": 500}

slack_events_adapter = SlackEventAdapter(
    SLACK_SIGNING_SECRET, "/slack/events", app
)  

#return upcoming games for specified url
def get_games(url, results, index2):

  today = datetime.date.today()
  next_week = today + datetime.timedelta(days=6)

  r = requests.get(url)
  root = BeautifulSoup(r.content, "html.parser")
  table = root.findAll("table")
  df_mbb = pd.read_html(str(table))[0]

  dates = ""

  for index, row in df_mbb.iterrows():
    #Clean the date to the right date format
    date_string = str(row['Date']).split('(')
    date_obj = datetime.datetime.strptime(date_string[0].strip(), "%B %d, %Y")
    date = date_obj.date()
    #timedelta = date - today

    #Check if date in range
    if(today<date and date<next_week ):
      dates = dates + "* " + (str(row["Opponent"]) + " on " + date_string[0] +"\n")
  
 
  if dates != "":
    results[index2] = sports[index2] + "\n" + dates

  return dates
# def get_games(url):

#   today = datetime.date.today()
#   next_week = today + datetime.timedelta(days=6)

#   r = requests.get(url)
#   root = BeautifulSoup(r.content, "html.parser")
#   table = root.findAll("table")
#   df_mbb = pd.read_html(str(table))[0]

#   dates = ""

#   for index, row in df_mbb.iterrows():
#     #Clean the date to the right date format
#     date_string = str(row['Date']).split('(')
#     date_obj = datetime.datetime.strptime(date_string[0].strip(), "%B %d, %Y")
#     date = date_obj.date()
#     #timedelta = date - today

#     #Check if date in range
#     if(today<date and date<next_week ):
#       dates = dates + ("* " + str(row["Opponent"]) + " on " + date_string[0] +"\n")

#   return dates

#return string of upcoming games
# def sports_cal():
#     sports = ["⚾ BASEBALL", "🏑 FIELD HOCKEY", "🏈 FOOTBALL", "🤸‍♀️ GYMNASTICS", "🏀 MEN'S BASKETBALL", "🥍 MEN'S LACROSSE", "⚽ MEN'S SOCCER", "🥎 SOFTBALL", "🏐 VOLLEYBALL", "🏀 WOMEN'S BASKETBALL", "🥍 WOMEN'S LACROSSE", "⚽ WOMEN'S SOCCER", "🎾 WOMEN'S TENNIS", "🤼‍♂️ WRESTLING" ]
#     bb = "https://umterps.com/sports/baseball/schedule?print=true"
#     fh = "https://umterps.com/sports/field-hockey/schedule?print=true" 
#     fb = "https://umterps.com/sports/football/schedule?print=true"
#     gym = "https://umterps.com/sports/womens-gymnastics/schedule?print=true"
#     mbb = "https://umterps.com/sports/mens-basketball/schedule?print=true"
#     mlax = "https://umterps.com/sports/mens-lacrosse/schedule?print=true"
#     msoc = "https://umterps.com/sports/mens-soccer/schedule?print=true"
#     sb = "https://umterps.com/sports/softball/schedule?print=true"
#     vb = "https://umterps.com/sports/womens-volleyball/schedule?print=true"
#     wbb = "https://umterps.com/sports/womens-basketball/schedule?print=true"
#     wlax = "https://umterps.com/sports/womens-lacrosse/schedule?print=true"
#     wsoc = "https://umterps.com/sports/womens-soccer/schedule?print=true"
#     wten = "https://umterps.com/sports/womens-tennis/schedule?print=true"
#     wrest = "https://umterps.com/sports/wrestling/schedule?print=true"

#     urls = [bb,fh,fb,gym,mbb,mlax,msoc,sb,vb,wbb,wlax,wsoc,wten,wrest]

#     to_return = ""

#     for i in range(14) :
#      res = get_games(urls[i])
#      if len(res)>0:
#         to_return = to_return + sports[i] + "\n" + res + "\n"

#     return to_return

def sports_cal():
    sports = ["⚾ BASEBALL", "🏑 FIELD HOCKEY", "🏈 FOOTBALL", "🤸‍♀️ GYMNASTICS", "🏀 MEN'S BASKETBALL", "🥍 MEN'S LACROSSE", "⚽ MEN'S SOCCER", "🥎 SOFTBALL", "🏐 VOLLEYBALL", "🏀 WOMEN'S BASKETBALL", "🥍 WOMEN'S LACROSSE", "⚽ WOMEN'S SOCCER", "🎾 WOMEN'S TENNIS", "🤼‍♂️ WRESTLING" ]
    bb = "https://umterps.com/sports/baseball/schedule?print=true"
    fh = "https://umterps.com/sports/field-hockey/schedule?print=true" 
    fb = "https://umterps.com/sports/football/schedule?print=true"
    gym = "https://umterps.com/sports/womens-gymnastics/schedule?print=true"
    mbb = "https://umterps.com/sports/mens-basketball/schedule?print=true"
    mlax = "https://umterps.com/sports/mens-lacrosse/schedule?print=true"
    msoc = "https://umterps.com/sports/mens-soccer/schedule?print=true"
    sb = "https://umterps.com/sports/softball/schedule?print=true"
    vb = "https://umterps.com/sports/womens-volleyball/schedule?print=true"
    wbb = "https://umterps.com/sports/womens-basketball/schedule?print=true"
    wlax = "https://umterps.com/sports/womens-lacrosse/schedule?print=true"
    wsoc = "https://umterps.com/sports/womens-soccer/schedule?print=true"
    wten = "https://umterps.com/sports/womens-tennis/schedule?print=true"
    wrest = "https://umterps.com/sports/wrestling/schedule?print=true"

    urls = [bb,fh,fb,gym,mbb,mlax,msoc,sb,vb,wbb,wlax,wsoc,wten,wrest]

    to_return = ""

    threads = [None] * 14
    results = [None] * 14

    for i in range(14) :
        curUrl = str(urls[i])
        threads[i] = Thread (target=get_games, args=(curUrl,results, i))
        threads[i].start()


    for i in range(14) :
        threads[i].join()


    for line in results:
        if line != None:
            to_return = to_return + str(line)


    return to_return

def pi_digits(x):
    """Generate x digits of Pi."""
    k,a,b,a1,b1 = 2,4,1,12,4
    while x > 0:
        p,q,k = k * k, 2 * k + 1, k + 1
        a,b,a1,b1 = a1, b1, p*a + q*a1, p*b + q*b1
        d,d1 = a/b, a1/b1
        while d == d1 and x > 0:
            yield int(d)
            x -= 1
            a,a1 = 10*(a % b), 10*(a1 % b1)
            d,d1 = a/b, a1/b1

@app.route('/sports-staff',methods=['POST', 'GET'])
def get_sports_directory():


    print("[!] scrape program start...")
    url = "https://umterps.com/staff-directory"

    r = requests.get(url)
    print("fetch status => " + str(r.status_code))

    root = BeautifulSoup(r.content, "html.parser")
    table = root.findAll("table")
    dataFrame = pd.read_html(str(table[1]))[0]

    # Assign column names. Don't remove "dummy"!
    dataFrame.columns = ['title', 'image', 'name', 'phone', 'dummy', 'twitter', ]

    # Drop the columns that you don't need
    dataFrame.drop(['dummy', 'image', 'phone', 'twitter'], axis=1, inplace=True)

    # remove the very first row, has weird dummy values
    dataFrame = dataFrame.iloc[1: , :]

    # target entered by user
    target  = request.form.get('text')
    print(target)

    matchFound = False
    title = ""

    # For loop to iterate over all the rows
    for index, row in dataFrame.iterrows():

        clean_name = row['name'].strip().upper()

        if target.strip().upper() == clean_name:
            print("match found with " + clean_name)
            print('[!] match found return it now')
            matchFound = True
            title = row['title']
            print("TITLE MATCH " + title)

    if matchFound:
        custom_text = "✔️ " + target + " is the " + title
    elif target.strip().upper() == "MIKE LOCKSLEY":
        custom_text = "🏈 Mike Locksley is spelled correctly"
    else:
        custom_text = "⚠️ " + target.strip() + " is not in the directory. Check spelling or the list of sports staff here: https://umterps.com/staff-directory"

    # Constructing the repsonse object
    response = make_response(custom_text, 200)

    response.mimetype = "text/plain"
    return response

#generic function with parameters for column names
def get_player(target, url, sym, name, academic_year, home):
    url_print = url + "?print=true"
    r = requests.get(url_print)
    print("fetch status => " + str(r.status_code))

    root = BeautifulSoup(r.content, "html.parser")
    table = root.findAll("table")
    dataFrame = pd.read_html(str(table))[2]

    rows = root.select('table > tbody > tr')
    #create array of links to player bios
    links = []
    for row in rows[2:]:  # omit header row
        cols = row.find_all('td')
        fields = [td.text.strip() for td in cols if td.text.strip()]

        if fields:  # if the row is not empty
            link = row.find('a')['href']
            links.append("https://umterps.com"+link)
        else:
            links.append("NO LINK")

    dataFrame['link'] = pd.Series(links)


    matchFound = False
    position = ""
    link = ""
    
    for index, row in dataFrame.iterrows():

        clean_name = row[name].strip().upper()

        if target.strip().upper() == clean_name:
            matchFound = True
            year = str(row[academic_year])
            if year in years:
                year = years[year]

            hometown = str(row[home])
            position = str(row['Pos.'])
            link = str(row['link'])
            break

    if matchFound:
        custom_text = sym + target + " is a " + year +  " from " + hometown + "\nPosition: " + position + "\nLearn more about " + target.strip().split()[0] +" here: " + link
    else:
        names_col = dataFrame.loc[:,name]
        names = names_col.values
        custom_text = "⚠️ " + target +" is not on the roster. Check spelling or the roster here: " +  url
        match  = difflib.get_close_matches(target, names, n=1)
        if (match):
            custom_text += "\nClosest match: " + match[0] 
    print (custom_text)
    
    return custom_text

#Gymnastics
@app.route('/gymnastics',methods=['POST', 'GET'])
def get_player_gymnastics():
    #parameters
    target  = request.form.get('text')
    url = "https://umterps.com/sports/womens-gymnastics/roster" 
    sym = "🤸 "
    name = 'Full Name'
    academic_year = 'Academic Year'
    home = 'Hometown'
    # Call function 
    custom_text = get_player(target, url, sym, name, academic_year, home)
    response = make_response(custom_text, 200)
    response.mimetype = "text/plain"
    return response

#Men's basketball
@app.route('/mens-basketball',methods=['POST', 'GET'])
def get_player_mens_basketball():
    #parameters for headings
    target  = request.form.get('text')
    url = "https://umterps.com/sports/mens-basketball/roster" 
    sym = "🏀 "
    name = 'Full Name'
    academic_year = 'Year'
    home = 'Hometown / HS / Prev. School'
    # Call function 
    custom_text = get_player(target, url, sym, name, academic_year, home)
    response = make_response(custom_text, 200)
    response.mimetype = "text/plain"
    return response

#Men's lacrosse
@app.route('/mlax',methods=['POST', 'GET'])
def get_player_mens_lacrosse():
    #parameters for headings
    target  = request.form.get('text')
    url = "https://umterps.com/sports/mens-lacrosse/roster" 
    sym = "🥍 "
    name = 'Full Name'
    academic_year = 'Year'
    home = 'Hometown / High School'
    # Call function 
    custom_text = get_player(target, url, sym, name, academic_year, home)
    response = make_response(custom_text, 200)
    response.mimetype = "text/plain"
    return response

#Women's lacrosse
@app.route('/wlax',methods=['POST', 'GET'])
def get_player_womens_lacrosse():
    #parameters for headings
    target  = request.form.get('text')
    url = "https://umterps.com/sports/womens-lacrosse/roster" 
    sym = "🥍 "
    name = 'Name'
    academic_year = 'Year'
    home = 'Hometown / High School'
    # Call function 
    custom_text = get_player(target, url, sym, name, academic_year, home)
    response = make_response(custom_text, 200)
    response.mimetype = "text/plain"
    return response

#Football
@app.route('/football',methods=['POST', 'GET'])
def get_player_football():
    #parameters for headings
    target  = request.form.get('text')
    url = "https://umterps.com/sports/football/roster" 
    sym = "🏈 "
    name = 'Full Name'
    academic_year = 'Academic Year'
    home = 'Hometown / High School'
    # Call function 
    custom_text = get_player(target, url, sym, name, academic_year, home)
    response = make_response(custom_text, 200)
    response.mimetype = "text/plain"
    return response

#Women's basketball
@app.route('/womens-basketball',methods=['POST', 'GET'])
def get_player_womens_basketball():
    target  = request.form.get('text')
    url = "https://umterps.com/sports/womens-basketball/roster" 
    sym = "🏀 "
    name = 'Name'
    academic_year = 'Year'
    home = 'Hometown / High School'
    # Call function 
    custom_text = get_player(target, url, sym, name, academic_year, home)
    response = make_response(custom_text, 200)
    response.mimetype = "text/plain"
    return response

#Field hockey
@app.route('/field-hockey',methods=['POST', 'GET'])
def get_player_field_hockey():
    target  = request.form.get('text')
    url = "https://umterps.com/sports/field-hockey/roster" 
    sym = "🏑 "
    name = 'Name'
    academic_year = 'Year'
    home = 'Hometown / High School'
    # Call function 
    custom_text = get_player(target, url, sym, name, academic_year, home)
    response = make_response(custom_text, 200)
    response.mimetype = "text/plain"
    return response

#Baseball
@app.route('/baseball',methods=['POST', 'GET'])
def get_player_baseball():

    target  = request.form.get('text')
    print(target)

    url = "https://umterps.com/sports/baseball/roster"
    sym = "⚾ "
    name = 'Full Name'
    academic_year = 'Academic Year'
    home = 'Hometown / High School'
    custom_text = get_player(target, url, sym, name, academic_year, home)
    # Constructing the repsonse object
    response = make_response(custom_text, 200)

    response.mimetype = "text/plain"
    return response

#Softball
@app.route('/softball',methods=['POST', 'GET'])
def get_player_softball():

    target  = request.form.get('text')
    print(target)

    url = "https://umterps.com/sports/softball/roster"
    sym = "🥎 "
    name = 'Full Name'
    academic_year = 'Academic Year'
    home = 'Hometown / High School'
    custom_text = get_player(target, url, sym, name, academic_year, home)
    # Constructing the repsonse object
    response = make_response(custom_text, 200)

    response.mimetype = "text/plain"
    return response

#Volleyball
@app.route('/volleyball',methods=['POST', 'GET'])
def get_player_volleyball():

    target  = request.form.get('text')
    print(target)

    url = "https://umterps.com/sports/womens-volleyball/roster"
    sym = "🏐 "
    name = 'Full Name'
    academic_year = 'Year'
    home = 'Hometown / High School'
    custom_text = get_player(target, url, sym, name, academic_year, home)
    # Constructing the repsonse object
    response = make_response(custom_text, 200)

    response.mimetype = "text/plain"
    return response

#Women's soccer
@app.route('/womens-soccer',methods=['POST', 'GET'])
def get_player_womens_soccer():

    target  = request.form.get('text')
    print(target)

    url = "https://umterps.com/sports/womens-soccer/roster"
    sym = "⚽ "
    name = 'Full Name'
    academic_year = 'Year'
    home = 'Hometown / High School'
    custom_text = get_player(target, url, sym, name, academic_year, home)
    # Constructing the repsonse object
    response = make_response(custom_text, 200)

    response.mimetype = "text/plain"
    return response

#Wrestling
@app.route('/wrestling',methods=['POST', 'GET'])
def get_player_wrestling():
    #parameters
    target  = request.form.get('text')
    url = "https://umterps.com/sports/wrestling/roster" 
    sym = "🤼 "
    name = 'Full Name'
    academic_year = 'Year'
    home = 'Hometown / High School'
    
    url_print = url + "?print=true"
    r = requests.get(url_print)
    print("fetch status => " + str(r.status_code))

    root = BeautifulSoup(r.content, "html.parser")
    table = root.findAll("table")
    dataFrame = pd.read_html(str(table))[2]

    rows = root.select('table > tbody > tr')
    #create array of links to player bios
    links = []
    for row in rows[2:]:  # omit header row
        cols = row.find_all('td')
        fields = [td.text.strip() for td in cols if td.text.strip()]

        if fields:  # if the row is not empty
            link = row.find('a')['href']
            links.append("https://umterps.com"+link)
        else:
            links.append("NO LINK")

    dataFrame['link'] = pd.Series(links)


    matchFound = False
    link = ""
    
    for index, row in dataFrame.iterrows():

        clean_name = row[name].strip().upper()

        if target.strip().upper() == clean_name:
            matchFound = True
            year = str(row[academic_year])
            if year in years:
                year = years[year]

            hometown = str(row[home])
            link = str(row['link'])
            break

    if matchFound:
        custom_text = sym + target + " is a " + year +  " from " + hometown + "\nLearn more about " + target.strip().split()[0] +" here: " + link
    else:
        names_col = dataFrame.loc[:,'Full Name']
        names = names_col.values
        custom_text = "⚠️ " + target +" is not on the roster. Check spelling or the roster here: " +  url
        match  = difflib.get_close_matches(target, names, n=1)
        if (match):
            custom_text += "\nClosest match: " + match[0] 
    response = make_response(custom_text, 200)
    response.mimetype = "text/plain"
    return response

#Men's soccer 
@app.route('/mens-soccer',methods=['POST', 'GET'])
def get_player_soccer():

    target  = request.form.get('text')
    print(target)

    url = "https://umterps.com/sports/mens-soccer/roster?print=true"

    r = requests.get(url)
    print("fetch status => " + str(r.status_code))

    root = BeautifulSoup(r.content, "html.parser")
    table = root.findAll("table")
    dataFrame = pd.read_html(str(table))[2]

    rows = root.select('table > tbody > tr')
    #create array of links to player bios
    links = []
    for row in rows[2:]:  # omit header row
        cols = row.find_all('td')
        fields = [td.text.strip() for td in cols if td.text.strip()]

        if fields:  # if the row is not empty
            link = row.find('a')['href']
            links.append("https://umterps.com"+link)
        else:
            links.append("NO LINK")

    dataFrame['link'] = pd.Series(links)


    matchFound = False
    year = ""
    major = ""
    hometown = ""
    position = ""
    link = ""
    
    for index, row in dataFrame.iterrows():

        clean_name = row['Full Name'].strip().upper()

        if target.strip().upper() == clean_name:
            matchFound = True
            year = str(row['Year'])
            if year in years:
                year = years[year]

            major = str(row['Major'])
            hometown = str(row['Hometown / High School'])
            position = str(row['Pos.'])
            link = str(row['link'])
            break

    if matchFound:
        custom_text = "⚽ " +  target + " is a " + year + " majoring in "  + major + ". He is from " + hometown + "\n  Position: " + position + "\nLearn more about him here: " + link
    else:
        names_col = dataFrame.loc[:,'Full Name']
        names = names_col.values
        custom_text = "⚠️ " + target +" is not on the roster. Check spelling or the men's soccer roster here: https://umterps.com/sports/mens-soccer/roster \n"
        match  = difflib.get_close_matches(target, names, n=1)
        if (match):
            custom_text += "Closest match: " + match[0] 
    # Constructing the repsonse object
    response = make_response(custom_text, 200)

    response.mimetype = "text/plain"
    return response

  
@app.route('/major',methods=['POST', 'GET'])
def get_major():

    print("[!] access to major triggered")
    umdRequest = urllib.request.urlopen("https://api.umd.io/v1/majors/list")
    data = json. load(umdRequest)

    # Target_request is the text data after /major
    target_request  = request.form.get('text').strip()

    # Initialized found to false and targetField o empty
    found = False
    target_field = ""
    for field in data:     
        if target_request.upper() == field['name'].strip().upper():        
            found = True
            target_field = field            

    if found:
        custom_text = "✔️ " +  target_request + " is a major. It is in the " + target_field['college']
    else:
        custom_text = "⚠️ Major does not exist. Check spelling or the list of majors here: https://www.admissions.umd.edu/explore/majors"

    # Constructing the repsonse object
    response = make_response(custom_text, 200)

    
    response.mimetype = "text/plain"
    return response

#Command to convert to reacts
@app.route('/rina',methods=['POST', 'GET'])
def rina_react():
    channel = request.form.get('channel_id')
    text = request.form.get('text').strip().upper()
    reacts_text = ''
    
    for char in text:
        if char in reacts:
            reacts_text = reacts_text + reacts[char]
        else:
          reacts_text = reacts_text + char  

    client.chat_postMessage(channel=channel, text = reacts_text)

    return make_response("", 200)

#Command for pi
@app.route('/pi',methods=['POST', 'GET'])

def pi():
    channel = request.form.get('channel_id')
    text = request.form.get('text').strip()

    if text.isnumeric():
        num  = int(text)
        digits = [str(n) for n in list(pi_digits(num))]
        pi = "%s.%s\n" % (digits.pop(0), "".join(digits))
        client.chat_postMessage(channel=channel, text = str(pi))
    else:
        pi = np.pi
        client.chat_postMessage(channel=channel, text = str(pi))

    return make_response("", 200)

#command to send sports calendar
@app.route('/sports-cal', methods = ['POST', 'GET'])
def get_sports_cal():
    channel = request.form.get('channel_id')
    today = datetime.date.today()
    today_format = today.strftime("%B %d")
    msg = "Upcoming sports games for week of " + str(today_format) + ":\n" 
    cal = sports_cal()

    if(len(cal)>0):
        msg = msg + cal
        client.chat_postMessage(channel = channel, text = msg)
        
    return make_response("", 200)
#Command to count characters
@app.route('/char-count',methods=['POST', 'GET'])
def get_char_count():
    #get input and count characters
    target  = request.form.get('text').strip()
    count = len(target)
    custom_text = str(count) + ": " + target

    #https://api.slack.com/messaging/attachments-to-blocks
    payload = {
        
	"blocks": [
		{
			"type": "section",
			"text": {
				"type": "mrkdwn",
				"text": custom_text
			}
		},
		{
			"type": "actions",
			"elements": [
				{
					"type": "button",
                    "value": custom_text,
					"text": {
						"type": "plain_text",
						"text": "Send to channel",
					}
				}
                # ,
				# {
				# 	"type": "button",
                #     "value": target,
				# 	"text": {
				# 		"type": "plain_text",
				# 		"text": "Copy text",
				# 	}
				# }                
			]
		}
	]
}


    # response = make_response(custom_text, 200)
    # response.mimetype = "text/plain"

    return Response(json.dumps(payload), mimetype='application/json')

@app.route("/slack/message_actions", methods=["POST"])
def message_actions():
    req = request.form.to_dict()
    data = json.loads(req["payload"])

    # Check to see what the user's selection was and update the message accordingly
    #selection = form_json["actions"][0]["selected_options"][0]["value"]
    channel = data["channel"]["id"]
    
   # if (data["actions"][0]["value"] == "send"):
    if (data["actions"][0]["text"]["text"] == "Send to channel"):
       # text = data["section"]["text"]
       #extract username 
       username = str(data["user"]["username"])
       tag_user = "<@"+username+">"

       text = str(data["actions"][0]["value"]) + " | ✍ " + tag_user
       
       client.chat_postMessage(channel=channel, text = text)
    
    # elif (data["actions"][0]["text"]["text"] == "Copy text"):
    #     text_df = pd.DataFrame([str(data["actions"][0]["value"])])
    #     text_df.to_clipboard(index=False,header=False)

    return make_response("", 200)

@slack_events_adapter.on('message')
def quick_response(payload):
    x = threading.Thread(
            target=text_detected,
            args=(payload,)
        )
    x.start()
    return make_response("", 200)

def text_detected(payload):
    
    event = payload.get('event', {})
    channel_id = event.get('channel')
    text = event.get('text')
    #ts = event.get('ts')
    #lowercase
    text = text.lower()

    #Send message to managing when a blog is detected in news_desk
    if (("@staffwriters" in text) and (("blog" in text) or ("email" in text))):
        #Posts message to managing channel
        client.chat_postMessage(channel = "GA9REFTC4", text = "A blog might be on the horizon :sunrise:")
    if("sports calendar incoming" in text):
        today = datetime.date.today()
        today_format = today.strftime("%B %d")
        msg = "Upcoming sports games for week of " + str(today_format) + ":\n" 
        cal = sports_cal()
        client.chat_postMessage(channel = channel_id, text = msg)
       #client.chat_postMessage(channel = "C02T9K2KCTS", text = msg)
        client.chat_postMessage(channel = channel_id, text = cal)
       # client.chat_postMessage(channel = "C02T9K2KCTS", text = cal)
    if("pubbed summary" in text):
         now = datetime.datetime.now()
         yesterday = now - datetime.timedelta(days=1) 
         dt_string = yesterday.strftime("%d/%m/%Y %H:%M:%S")
         starttime = str(datetime.datetime.strptime(dt_string, "%d/%m/%Y %H:%M:%S").timestamp()) #string for last 24 hrs time stamp

         result = client.conversations_history(
            channel="C02T9K2KCTS",
            inclusive=False,   #Ensures that specified timestamp is in result
            oldest=starttime,  #Starting point for search
            
        )
         messages = result["messages"]
         if messages:
            client.chat_postMessage(channel = "C1YHLNULT", text = "News stories in the past day:" )
            for message in messages:
                link = message["text"].split('\n', 1)[0]
                #Gives link without "unfurling" in quoted text format
                client.chat_postMessage(channel = "C1YHLNULT", text = ">" + link , unfurl_links=False)

    if("pubbed weekly" in text):
         now = datetime.datetime.now()
         yesterday = now - datetime.timedelta(weeks=1) 
         dt_string = yesterday.strftime("%d/%m/%Y %H:%M:%S")
         starttime = str(datetime.datetime.strptime(dt_string, "%d/%m/%Y %H:%M:%S").timestamp()) #string for last 24 hrs time stamp

         result = client.conversations_history(
            channel="C02T9K2KCTS",
            inclusive=False,   #Ensures that specified timestamp is in result
            oldest=starttime,  #Starting point for search
            
        )
         messages = result["messages"]
         if messages:
            ts_id = ""
            response = client.chat_postMessage(channel = "C0BTWCFFF", text = "News stories in the past week:" )
            ts_id = ts_id+response['ts']
            for message in messages:
                link = message["text"].split('\n', 1)[0]
                #Gives link without "unfurling" in quoted text format
                client.chat_postMessage(channel = "C0BTWCFFF", thread_ts = ts_id, text = ">" + link , unfurl_links=False)

        #  now = datetime.datetime.now()
        #  last_week = now - datetime.timedelta(weeks=1) 
        #  dt_string = last_week.strftime("%d/%m/%Y %H:%M:%S")
        #  starttime = str(datetime.datetime.strptime(dt_string, "%d/%m/%Y %H:%M:%S").timestamp()) #string for last week

        #  result = client.conversations_history(
        #     channel="C02T9K2KCTS",
        #     inclusive=False,   #Ensures that specified timestamp is in result
        #     oldest=starttime,  #Starting point for search
            
        # )

        #  messages = result["messages"]
        #  num = 0
        #  for message in messages:
        #     num = num + 1
    
        #  client.chat_postMessage(channel = "C02MXKZETU3", text = "The Diamondback published " + num +" news stories this past week.")





        #client.chat_postMessage(channel = "C02MXKZETU3", text = sports_cal())
# @slack_events_adapter.on('workflow_step_execute')
# def sports_cal_step(event_data):
#     event = event_data["event"]
#     today = datetime.date.today()
#     msg = "Upcoming sport games for week of " + str(today) + "\n" 
#     cal = sports_cal()

#     if(len(cal)>0):
#         msg = msg + cal
#         client.chat_postMessage(channel = "C02MXKZETU3", text = msg)


@slack_events_adapter.on('reaction_added')
def reaction_added(event_data):
    event = event_data["event"]
    #emoji = event["reaction"]
    channel_id = event["item"]["channel"]

    msg_ts = event["item"]["ts"]
    
    if event['reaction'] in ('1234'):
        if event["item"]["type"] == 'message':
            # https://api.slack.com/methods/conversations.history
            result = client.conversations_history(
            channel=channel_id,
            inclusive=True,   #Ensures that specified timestamp is in result
            oldest=msg_ts,  #Starting point for search
            limit=1   #Looks for 1 match
        )

            message = result["messages"][0]
            #Text is attribute 
            msg_text = message["text"]
            count = len(msg_text)
            client.chat_postMessage(channel=channel_id,  thread_ts = msg_ts, text=str(count))

    #Threads message reacted to in reacts
    if event['reaction'] in ('rinalaughing'):
        if event["item"]["type"] == 'message':
            # https://api.slack.com/methods/conversations.history
            result = client.conversations_history(
            channel=channel_id,
            inclusive=True,   #Ensures that specified timestamp is in result
            oldest=msg_ts,  #Starting point for search
            limit=1   #Looks for 1 match
        )

            message = result["messages"][0]
            #Text is attribute 
            msg_text = message["text"].upper()

            reacts_text = ''
            #convert to reacts
            for char in msg_text:
                if char in reacts:
                    reacts_text = reacts_text + reacts[char]
                else:
                    reacts_text = reacts_text + char  

            client.chat_postMessage(channel=channel_id,  thread_ts = msg_ts, text=reacts_text)
    


# def reaction_added_event(request, parsed):
#     print(parsed)
#     event = parsed['event']
#     if event['reaction'] in ('1234', 'count'):
#         item = event['item']
#         if item['type'] == 'message':
#             print("yes, handling this message")
#             channel = item['channel']
#             msg_ts = item['ts']
#             msg = get_message(channel, msg_ts)
#             client.chat_postMessage(channel=channel, text = "test")
#     return "Ok"
#def reaction_added_count(payload):
    #event = payload.get('event', {}) 
    # if event ['reaction'] not in ('1234'):
    #     return

    # #payload sent back -- item reaction and channel it was in
    # channel_id = event.get('item', {}).get('channel')
    # user_id = event.get('user')
    # #timestamp is very precise -- can use to ID msg
    # ts = event.get('item', {}).get('ts')
    # type = event.get('item', {}).get('type')
    # #count = len(text)

    # if event['reaction'] in ('1234'):
    #     item = event['item']
    #     if item['type'] == 'message':
    #         channel_id = item['channel']
    #         msg_ts = item['ts']
    #        # msg = get_message(channel_id, msg_ts)
    #         #client.chat_postMessage(channel=channel_id, thread_ts = msg_ts, text = "test")
    #         client.chat_postMessage(channel=channel_id, text = "test")

 

# @slack_events_adapter.on("app_mention")
# def handle_message(event_data):
#     def send_reply(value):
#         event_data = value
#         message = event_data["event"]
#         if message.get("subtype") is None:
#             command = message.get("text")
#             channel_id = message["channel"]
#             if any(item in command.lower() for item in greetings):
#                 message = (
#                     "Hello <@%s>! :tada:"
#                     % message["user"]  # noqa
#                 )
#                 slack_client.chat_postMessage(channel=channel_id, text=message)
#     thread = Thread(target=send_reply, kwargs={"value": event_data})
#     thread.start()
#     return Response(status=200)


# Start the server on port 3000
if __name__ == "__main__":
  app.run(port=3000)
 # slack_events_adapter.start()